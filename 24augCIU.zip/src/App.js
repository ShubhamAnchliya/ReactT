import React from 'react'
import { Route, Routes } from 'react-router-dom';
import AddUser from './Component/AddUser/AddUser';
import Navbar from './Component/Navbar/Navbar';
import UpdateUser from './Component/UpdateUser/UpdateUser';
import UserList from './Component/UserList/UserList';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

const App = () => {
  return (
    <>

      <Navbar />
      
      <Routes>

        <Route path="/" element={<UserList/>} />


        <Route path="/user" element={<UserList/>} />

        <Route path="/adduser" element={<AddUser/>} />

        <Route path="/updateuser/:id" element={<UpdateUser/>} />

      </Routes>

    </>
  )
}

export default App;