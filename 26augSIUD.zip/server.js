const express = require("express");

const cors = require("cors");

const dbConfig = require('./config/database.js');

const user = require("./routes/userRoute.js")
// const user = require("./routes/upload.js")

const dotenv = require("dotenv");

const path = require('path');


const bodyParser = require('body-parser');

dotenv.config();

const app = express();

const PORT = process.env.PORT ;

dbConfig();

app.use(cors({ origin: true, credentials: true }));



// app.use(express.json({extended: false}));

// const bodyParser = require('body-parser');

app.use(bodyParser.json());

app.get('/', (req, res) => res.send('Server is running') );


app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use("/api", user);

// app.use(express.static(__dirname + '/uploads'));
// app.use("/uploads",express.static('images'))

app.listen(PORT, ()  => 
    console.log(`server is running on http://localhost:${PORT}`)
);