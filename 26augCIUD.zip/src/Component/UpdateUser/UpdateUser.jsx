import React, { useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import "./UpdateUser.css";
// import defaultImage from "../../assets/image/uploadimage.jpg";

const UpdateUser = () => {
  const navigate = useNavigate();

  const { id } = useParams();

  const [user, setUser] = useState();

  const [image, setImage] = useState({
    proPic: "",
  });

  // const [proPic, setproPic] = useState({
  //   previewPic: ""
  // })

  // var {
  //   firstName,
  //   // email,
  //   // mobile,
  //   profilePic,
  // } = user;

 

  useEffect(() => {
    const loadUserData = async () => {
      const res = await axios.get(`http://localhost:5000/api/user/${id}`);
      console.log("databyId", res.data.user);
      setImage({ proPic: `http://localhost:5000/` + res.data.user.profilePic })
      setUser(res.data.user);
    }
    loadUserData();
  },[id]);

  // const InputEvent = async (e) => {
  //   setUser({
  //     ...user,
  //     [e.target.name]: e.target.value,
  //   });
  //   // console.log("e.target.value", e.target.value);
  // };

  const handlePhoto = (e) => {
    var imgTarget = e.target.files[0];

    if (e.target.files && imgTarget) {
      setUser({ ...user, profilePic: imgTarget });
      setImage({ proPic: URL.createObjectURL(e.target.files[0]) });
    }
    // else{
    //     setUser({...user, profilePic: url });
    // }
  };

  const formSubmit = (e) => {
    e.preventDefault();

    // console.log("user", user);

    axios
      .put(`http://localhost:5000/api/user/${id}`, user, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((res) => {
        console.log("resUpdatedDataMessage", res.data.message);

        Swal.fire({
          position: "center",
          icon: "success",
          title: "User record has been updated",
          showConfirmButton: false,
          timer: 1000,
        });
      })

      .catch((err) => {
        console.log("Error couldn't add user");
        console.log(err.message);
      });

    // loadUserlist();

    navigate("/user");
  };

  return (
    <>
      <section id="editUser" className="editUser">
        <div className="container" data-aos="fade-up">
          <div className="section-title">
            <h2 className="text-center mt-4">Update User Detail</h2>
          </div>

          <div className="row ">
            <form className="editUser-form mt-4" onSubmit={formSubmit}>
              <div className="form-group ">
                <label htmlFor="profilePic"> Profile Pic</label>

                <div className="profile-image mb-3">
                  <img
                    // src={file}
                    src={image.proPic}
                    // src={`http://localhost:5000/`+profilePic }

                    alt="profilePic"
                    width="120"
                    height="120"
                    className="img"
                  />
                </div>

                <input
                  type="file"
                  name="profilePic"
                  accept=".png, .jpg, .jpeg"
                  className="form-control"
                  id="profilePic"
                  // value='profilePic'
                  onChange={handlePhoto}

                  // required
                />
              </div>

              <div className="text-center buttons">
                <button className="btn btn-primary mx-1" type="submit">
                  Update
                </button>
                <Link to={"/user"} className="btn btn-danger">
                  Cancel{" "}
                </Link>
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default UpdateUser;
