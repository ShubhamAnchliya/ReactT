import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import "./Navbar.css";
import { FaBars, FaTimes , FaRegLaughWink} from "react-icons/fa";

const Navbar = () => {

    const [click, setClick] = useState(false);

    const handleClick = () => setClick(!click);
    const Close = () => setClick(false);
    

  return (
    <>
        {/* <h1>NavBar</h1>  */}
        <div className={click ? "main-container" : ""}  onClick={()=>Close()} />  
        <nav className="navbar" onClick={e => e.stopPropagation()}>
        <div className="nav-container ">

          <Link to="/" className="nav-logo">
            FunnyBeam 
            <i className='emoji'><FaRegLaughWink/></i>
          </Link>

          <ul className={click ? "nav-menu active" : "nav-menu"}>

            <li className="nav-item">
              <Link
                to="/"
                activeclassname="active"
                className="nav-links"
                onClick={click ? handleClick : null}
              >
                UserList
              </Link>
            </li>

            <li className="nav-item">
              <Link
               
                to="/adduser"
                activeclassname="active"
                className="nav-links"
                onClick={click ? handleClick : null}
              >
                AddUser
              </Link>
            </li>
          
            <li className="nav-item">
              <Link
               
                to="/updateuser"
                activeclassname="active"
                className="nav-links"
                onClick={click ? handleClick : null}
              >
                UpdateUser
              </Link>
            </li>      

          </ul>

          <div className="nav-icon" onClick={handleClick}>
            {/* <i className={click ? "<FaTimes/>" : "<FaBars/>"}></i> */}
            {  click ? <FaTimes/>:<FaBars/>
            }         
          </div>

        </div>
      </nav> 
    </>
  )
}

export default Navbar;