import React, { useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useState } from 'react';
import axios from "axios";
import Swal from 'sweetalert2'; 
import "./UpdateUser.css";
// import defaultImage from "../../assets/image/uploadimage.jpg";




const UpdateUser = () => {

    const navigate = useNavigate();

    const { id } = useParams();

    const [user, setUser] = useState({
  
      firstName : "",
      email : "",
      mobile : "",
      // profilePic: defaultImage
      profilePic: ""
  
    });

    // const [file, setFile] = useState(
    //     defaultImage);
  
    const {
      firstName,
      email,
      mobile,
      profilePic
    
       
    } = user;
  
    const InputEvent = async (e) => {
      setUser({
        ...user, [e.target.name]: e.target.value
      })
      // console.log("e.target.value", e.target.value);
    };
  
  
    // const handlePhoto = (e) => {
    //   setUser({...user, profilePic: e.target.files[0]});
    // };





        const handlePhoto = (e) => {

            if(e.target.files && e.target.files[0]) {
                setUser({...user, profilePic: URL.createObjectURL(e.target.files[0])});
            }
            else{
                // setUser({...user, profilePic: defaultImage});
                setUser({...user, profilePic:""});
            }
           
          };

          useEffect(() => {
            // console.log("Employeedata use_effect");
            loadUserData();
          }, []);
        
          const loadUserData = async  () => {
            const res = await axios.get(`http://localhost:5000/api//user/${id}` );
            console.log("resU.data", res.data.user);
            setUser(res.data.user); 
          };
        





    // const handlePhoto = (e) => {
    //   setUser({...user, profilePic: URL.createObjectURL(e.target.files[0])});
    // };

    // const handlePhoto = (e) => {
    //     console.log(e.target.files);
    //     setFile(URL.createObjectURL(e.target.files[0]));
    // }

    const formSubmit =  (e) => {

      e.preventDefault();
  
      // console.log("user", user);
  
      axios
      .put(`http://localhost:5000/api/user/${id}`, user)
      .then((res) => {     
  
        console.log("resUpdatedDataMessage",res.data.message);
  
        // setUser('');
  
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'User record has been updated',
          showConfirmButton: false,
          timer: 1000
        })
        
      })

      .catch((err) => {
        console.log("Error couldn't add user");
        console.log(err.message);
      });
  
        navigate("/user");
  
    };
  

  return (

    <>

        <section id="editUser" className="editUser">

            <div className="container" data-aos="fade-up">

                <div className="section-title">
                    <h2 className='text-center mt-4'>Update User Detail</h2>
                </div>

                <div className="row ">

                    <form className="editUser-form mt-4" 
                    onSubmit={formSubmit}
                    >

                        <div className="form-group col-md">

                            <label htmlFor="firstName">First Name</label>

                            <input 
                                type="text" 
                                name="firstName" 
                                className="form-control" 
                                id="firstName" 
                                placeholder="Enter First Name"               
                                value={firstName}
                                onChange={InputEvent}
                                required 
                            />

                        </div>                        

                        <div className="form-group ">

                            <label htmlFor="email">Email</label>
                            
                            <input 
                                type="email" 
                                className="form-control" 
                                name="email" 
                                id="email" 
                                placeholder="Enter Email" 
                                value={email}
                                onChange={InputEvent}
                                required 
                            />
                        </div>                     

                        <div className="form-group ">

                            <label htmlFor="mobile">Mobile Number</label>

                            <input 
                                type="mobile" 
                                name="mobile" 
                                className="form-control" 
                                id="mobile" 
                                placeholder="Enter Contact Number"               
                                value={mobile}
                                onChange={InputEvent}
                                required 
                            />

                        </div>


                        <div className="form-group ">

                            <label htmlFor="profilePic"> Profile Pic</label>
          
                            <div className="profile-image mb-3">
                                <img 
                                    
                                    // src={file} 

                                    src={profilePic} 
                                    
                                    alt="profilePic" 
                                    
                                    width="120"
                                    height="120" 
                                    className="img" 
                                    
                                />
                            </div>

                            <input 
                                type="file" 
                                name="profilePic" 
                                accept=".png, .jpg, .jpeg"
                                className="form-control" 
                                id="profilePic" 
                                // value={profilePic}
                                onChange={handlePhoto}   
                                                                                               
                                // required 
                                
                            />

                        </div>
                    
                        <div className="text-center buttons">

                            <button className='btn btn-primary mx-1' type="submit">Update</button>
                            <Link to={'/user'} className='btn btn-danger' >Cancel </Link>

                        </div>

                    </form>

                </div>

            </div>

        </section>                             

    </>

  )

}


export default UpdateUser;








