
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import "./UserList.css";
import { FaRegEdit } from "react-icons/fa";
import { MdDeleteForever } from "react-icons/md";

import Swal from 'sweetalert2'; 


import {  ToastContainer , Flip } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const UserList = () => {

    const [user, setUser] = useState([]);

    const loadUsers = async () => {
	    await axios.get("http://localhost:5000/api/user")
		.then((res) => {
		  console.log(res.data.user);
		  setUser(res.data.user);
		})
		.catch((err) => {
		  console.log(err);
		});
	}


    useEffect(() => {

  
		loadUsers();
        // console.log(user);
      
    }, []);



		
	const deleteUser = async id  =>  {
		console.log("deleteId", id)

		Swal.fire({
		title: 'Are you sure?',
		text: "You won't be able to revert this!",
		icon: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: 'Yes, delete it!'
	    }).then((result) => {
		if (result.isConfirmed) {
			 axios.delete(`http://localhost:5000/api/user/${id}`)
			.then(res => {
			
				Swal.fire({
					position: 'center',
					icon: 'success',
					title: 'Selected user record has been deleted',
					showConfirmButton: false,
					timer: 1000
				  })
				  loadUsers();
			}
			
			);
		

		}
	  })
		
	  }




  return (

    <>

        <div className="main_div">

            <h2 className='mt-4 heading'>Users List</h2>

            <div className="edit-btns mb-2">

                <Link
                    
                    to={'/adduser'}
                    className="btn btn-primary btn-sm"
                    type="button"
                    >
                    Add Student

                </Link>

            </div>						
            
            <table className="table table-bordered  ">
                
                <thead>

                    <tr role="row">

                        <th>S.No.</th>
                        <th>User ID</th>
                        {/* <th>FirstName</th> */}
                        {/* <th>Email</th>
                        <th>Mobile</th> */}
                        <th>Profile Pic</th>                        
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {   
                        user.map((data , index) => (

                            <tr key={index}>

                            <td>{index+1}</td>
                            <td>{data._id}</td>
                            {/* <td>{data.firstName}</td> */}
                            {/* <td>{data.email}</td>
                            <td>{data.mobile}</td> */}
                  
                            <td>
                                <div className="">
                                    <img 
                                        src={`http://localhost:5000/`+data.profilePic}

                                        alt="profilePic" 

                                    //  width="100px"

                                        width="120"
                                        height="120"
                                        className="img-fluid"
                                         />
                                </div>
                            </td>
                                    

                            <td className='action_btn'>

                                <Link
                                    className="btn ebtn btn-sm"
                                    to={`/updateuser/${data._id}`}

                                    // onClick={showToastMessage}
                                >

                                <FaRegEdit/> 
                                
                                <ToastContainer
                                    position="top-right"
                                    autoClose={1500}
                                    hideProgressBar={false}
                                    newestOnTop={false}
                                    closeOnClick
                                    rtl={false}
                                    pauseOnFocusLoss={false}
                                    draggable
                                    pauseOnHover
                                    transition={Flip}
                                    theme= "dark"

                                />
                                </Link>

                                <Link
                                    className="btn dbtn btn-sm"
                                    to="/user"
                                    onClick={() => deleteUser(data._id)}
                                    >
                                    <MdDeleteForever/>
                                </Link>

                            </td>                                                 

                        </tr>

                        ))
                    }

                </tbody>
            </table>

        </div>

       
     
    </>

  )
}

export default UserList;